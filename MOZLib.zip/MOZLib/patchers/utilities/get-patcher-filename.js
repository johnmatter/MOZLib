outlets = 2;

function bang() {
    outlet(0,this.patcher.filepath);
    outlet(1,this.patcher.name);
}