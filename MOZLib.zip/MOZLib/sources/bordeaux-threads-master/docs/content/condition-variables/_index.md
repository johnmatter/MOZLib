---
date: 2022-01-07T08:00:00Z
title: Condition Variables dictionary
weight: 4
---

##### [Class CONDITION-VARIABLE](condition-variable)

##### [Function CONDITION-VARIABLE-P](condition-variable-p)

##### [Function MAKE-CONDITION-VARIABLE](make-condition-variable)

##### [Function CONDITION-WAIT](condition-wait)

##### [Function CONDITION-NOTIFY](condition-notify)

##### [Function CONDITION-BROADCAST](condition-broadcast)
