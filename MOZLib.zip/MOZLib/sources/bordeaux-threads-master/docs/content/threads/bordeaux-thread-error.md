---
date: 2022-01-07T08:00:00Z
title: 'Condition type BORDEAUX-THREADS-ERROR'
weight: 15
---

#### Class Precedence List:

bordeaux-threads-error, error, serious-condition, condition, t

#### Description:

The type **bordeaux-threads-error** consists of error conditions that
are related to thread operations.

#### See also:

[**abnormal-exit**](../abnormal-exit-condition)
