---
date: 2022-01-07T08:00:00Z
title: Class THREAD
weight: 1
---

#### Class precedence list:

[thread](.), [t](http://www.lispworks.com/documentation/HyperSpec/Body/t_t.htm#t)

#### Description:

A wrapper for host thread instances.
