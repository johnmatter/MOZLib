---
date: 2022-01-07T08:00:00Z
title: Timeouts dictionary
weight: 7
---

##### [Class TIMEOUT](timeout)

##### [Macro WITH-TIMEOUT](with-timeout)
