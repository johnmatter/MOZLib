# new-engine
A new constraint engine research by Örjan Sandred (2022) 
