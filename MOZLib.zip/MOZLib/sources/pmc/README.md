# pmc
A version of PWConstraints CSP solver
